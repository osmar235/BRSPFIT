clear all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Find optmized parameter for Brasil and Sao Paulo.
%Plot Model 95% Confidence Interval for Acc Cases and Acc Deaths.
%Author: Osmar Pinto Neto, Last modified 28052020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Set output file containg optmized parameter for Brasil and Sao Paulo.
outfile01= 'Parameters_19072020.DAT';                             
     fid01 = fopen(outfile01,'w');
     fprintf(fid01,'Region \t alpha \t beta \t Invtl \t Invti \t Invth \t Invtc \t ma \t ca \t fa \t E0 \t I0 \t H0 \t C0 \t R0 \t D0 \t RMSE'); 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Setting parameters for optimizations 

iteracoes=5000; %Number of iterations
globalSkip=2500; %Number of itereation before going back to initial guess
Peso_RAND=.4;    %Weight of randomness on next iterations
Peso_Atual=.6;   %Wight of current optimal solution in next iteration

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Setting parameters for Confidence Interval
NROD=300; %Number of iterations for CI Determination 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Inputs

%Regions names , population, cases factor and deats factor
Tablename1 = 'PAIS_POP_FATOR1_2_28052020.xls';
T1 = readtable(Tablename1);
paises=T1{:,1} ;
populacao=T1{:,2} ;
populacao=populacao.*1e6;
FATORCASOS=T1{:,3} ;
FATORMORTES=T1{:,4} ;

%Acc Cases, Acc deaths, and Recoveries 
Tablename2='dados_estados_completo_28052020.xls';
T2 = readtable(Tablename2);
fileData=T2{:,2:7};

%Initial guesses for alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0 
Tablename3 ='guesses_28052020_02.xls';
T3 = readtable(Tablename3);
fileDataGU=T3{:,2:14};

%Function to estimate social distance from Google and Apple's data
SDT = Funcao_GOOGLE_APPLE_28052020;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Loop to run optmization for Brazil and Sao Paulo

for i=1:2
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%input data for region    
Region=char(paises(i));    
caso(i,:)=  fileDataGU(i,:);
SD=SDT(:,i)./100;
  
DADOSMUNDO=fileData(:,(i*3-2:i*3));
Npop=populacao(i); 

CASOSREAL = FATORCASOS(i) * DADOSMUNDO(:,1);
DEATHSREAL = FATORMORTES(i)*DADOSMUNDO(:,2);
RECUPERADOSREAL=DADOSMUNDO(:,3);

casos_ativos=CASOSREAL;
casos_mortes=DEATHSREAL;
casos_recuperados=RECUPERADOSREAL;
N = length(CASOSREAL);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%setting model time resolution and starting and end data for model run
dt=.1;
t=0:dt:(730);
startDate = datenum('12-27-2019');
endDate = datenum('12-26-2021');
xData = linspace(startDate,endDate,7300);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Resampling of DATA

x = (1:N)'; 
y = CASOSREAL; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%CASOSREAL=p1(11:length(p1));
CASOSREAL=p1(1:length(p1));
y = DEATHSREAL; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%DEATHSREAL=p1(11:length(p1));
DEATHSREAL=p1(1:length(p1));
y = RECUPERADOSREAL; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%RECUPERADOSREAL=p1(11:length(p1));
RECUPERADOSREAL=p1(1:length(p1));
y = SD; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%RECUPERADOSREAL=p1(11:length(p1));
SD=p1(1:length(p1));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Starting analyses after 50 cases

N2 = length(CASOSREAL);
minNum=50;
CASOSREAL_orig=CASOSREAL;
t(CASOSREAL<=minNum)=[];
DEATHSREAL(CASOSREAL<=minNum)=[];
RECUPERADOSREAL(CASOSREAL<=minNum)=[];
SD(CASOSREAL<=minNum)=[];
xData(CASOSREAL<=minNum)=[];
CASOSREAL(CASOSREAL<=minNum)=[];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD set to zero for duration of time after present day not relevant for
%optmization
for cont=length(SD)+1:length(t)
    SD(cont)=mean(SD((length(CASOSREAL)-7):(length(SD))));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initial Guesses for Model initial values

pp=Npop/45919000; 
IHC0=CASOSREAL(1)*pp; %population adjusted
D0=DEATHSREAL(1);
I0=.9*fix(IHC0);
E0=fix(I0);
H0=I0;       %augmented testing
C0=fix(H0*.05);
R0=D0;

%%%%%%%%SOH PARA TESTAR
%IHC0=CASOSREAL(1); %population adjusted
%D0=DEATHSREAL(1);
%I0=.9*fix(IHC0);
%E0=fix(I0);
%H0=.8*I0;       %augmented testing
%C0=fix(H0*.4);
%R0=D0;
%%%%%%%%SOH PARA TESTAR


melhorcaso=caso;
alpha= caso(i,1); 
beta=caso(i,2);  
Invtl=caso(i,3);  
Invti=caso(i,4); 
Invth=caso(i,5); 
Invtc=caso(i,6); 
ma=caso(i,7);
la=0;            %la=caso(i,8);   %no deaths from lack of hospital beds
rla=caso(i,9);
midpla=caso(i,10);
dur=caso(i,11);
ca=caso(i,12);
fa=caso(i,13);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Run optimization Function

[alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,E0,I0,H0,C0,R0,D0,contador,contglobal,RMSE] = otimizador_OS_19072020(Peso_RAND,Peso_Atual,dt,CASOSREAL,DEATHSREAL,RECUPERADOSREAL,iteracoes,globalSkip,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Results from optmization
resultoptimization(i,:)=[alpha beta Invtl Invti Invth Invtc ma la rla midpla dur ca fa E0 I0 H0 C0 R0 D0 RMSE];


%Writing to primary output file
                            %---------------------------------------------------
                           fprintf(fid01,'\n %s \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e \t %e',Region,alpha,beta,Invtl,Invti,Invth,Invtc,ma,ca,fa,E0,I0,H0,C0,R0,D0,RMSE');
                           
Plot_modeloptimization_19072020(xData,dt,NROD,CASOSREAL,DEATHSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD)




end