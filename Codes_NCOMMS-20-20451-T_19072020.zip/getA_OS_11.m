function [A] = getA_OS_11(alpha,Invtl,Invti,Invth,Invtc,ma,la,fa,ca)

%INPUT
%model parameters: alpha,Invtl,Invti,Invth,Invtc,ma,la,fa,ca

%Output
%Matrix A of parameters for model equations for Differential Equations Solving

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Arrange Matrix 

        A = zeros(8);
        % S
        A(1,1) = -alpha;
        % E
        A(2,2) = -Invtl;
        % I
        A(3,2:3) = [Invtl,-Invti];
        % H
        A(4,3:5) = [Invti*(1-ma),-Invth,Invtc*(1-fa)];
        % C
        A(5,4:5) = [Invth*ca , -Invtc];
        % R
        A(6,3:4) = [Invti*(ma-la),Invth*(1-ca)];
        % D
        A(7,3:5) = [Invti*la,0,Invtc*fa];
        % P
        A(8,1) = alpha;
    
end