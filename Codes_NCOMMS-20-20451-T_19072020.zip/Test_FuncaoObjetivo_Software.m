%TEST OBJETIVE FUNCTION

%Choose Inputs
%INPUT
%CP: value for alpha after present day. RANGE USED:    max=0.28   min -0.5      
%ESTRATEGIA: Strategies tested; % 1 for stepping down 2 for intermittent or
%3 for Constant
%JANELA: # Number of days per window; Values: 1 for 40 days 2 for 60 days and 3 for 80 days 
%NOVOSD: 2 x the maximum SD values for stretagies 1 and 2 , 4 x the SD value for strategy 3 RANGE: max=1.5   min 0
%TEMPOCP %number of days from which protecion stays constant x 10. RANGE USED: min=300 %max=5000
%Region: 1 for Brazil 2 for S�o Paulo

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Inputs parameters
CP=0;
ESTRATEGIA=1;
JANELA=3;
NOVOSD=.8;
TEMPOCP=1200;
Region=2;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Xf0
Xfo=[CP ESTRATEGIA JANELA NOVOSD TEMPOCP Region];

%Run the Function
[ICU_E,Protection,ICUE1,ICUE2] = FuncaoObjetivo_Software(Xfo)

%Expected output:
%ICU_E = 8.0116e+04
%Protection = 59.6793
%ICUE1 =  7.6217e+04
%ICUE2 =   3.8989e+03