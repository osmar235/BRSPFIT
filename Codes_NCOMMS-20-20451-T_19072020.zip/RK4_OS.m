function [Y] = RK4_OS(Fun,Y,A,F,dt)

%Solve model differential equations using Runge-Kutta numerical solution of
% 4th order

        k_1 = Fun(Y,A,F);
        k_2 = Fun(Y+0.5*dt*k_1,A,F);
        k_3 = Fun(Y+0.5*dt*k_2,A,F);
        k_4 = Fun(Y+k_3*dt,A,F);
        
% output
        Y = Y + (1/6)*(k_1+2*k_2+2*k_3+k_4)*dt;
    end