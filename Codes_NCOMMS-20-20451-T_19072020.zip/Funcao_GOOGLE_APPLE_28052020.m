function SD = Funcao_GOOGLE_APPLE_28052020
 
%Description
%it filters data mobility data from Google and APPLE compare values to baseline values; 
%data from Google for retail_and_recreation_percent_change_from_baseline_Google	
%grocery_and_pharmacy_percent_change_from_baseline_Google	parks_percent_change_from_baseline_Google
%transit_stations_percent_change_from_baseline_Google and	workplaces_percent_change_from_baseline_Google_BR
%are averaged out and averaged with Apple's data for driving	
 

%INPUT
%Data filterd for Brazil and S�o Paulo From Google and APPLE:
%https://www.google.com/covid19/mobility/
%https://www.apple.com/covid19/mobility

Tablename4 = 'Data_google_apple_28052020.xls';
T4 = readtable(Tablename4);
fileData=T4{:,2:15};


for i=1:2
    
    
x=fileData(:,i);
t=1:1:length(x);
smplFrq=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % Filter

    freq=smplFrq;
    fNorm = 0.07 / (freq/2) ;                                                                                                           
    [f1, f2] = butter( 4, fNorm, 'low' );                                                         
    y = filtfilt(f1,f2,x);
    
    
     
  y=y-max(y);
  
  
  for cont=1:length(y)
      if y(cont)==0
          t0=cont;
          break
      end
  end
  
  mean0=mean(y(1:cont));
  
  for cont2=1:t0
      y(cont2)=0;
  end
  
  
  for cont2=t0+1:length(y)
      y(cont2)=y(cont2)-mean0;
      if y(cont2)>0
          y(cont2)=0;
      end
  end
  
  
  y=abs(y-100)-100;
  SD(:,i)=y;
  

end



for i=3:14
    
    
x=fileData(:,i);
t=1:1:length(x);
smplFrq=1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % Filter

    freq=smplFrq;
    fNorm = 0.07 / (freq/2) ;                                                                                                           
    [f1, f2] = butter( 4, fNorm, 'low' );                                                         
    y = filtfilt(f1,f2,x);
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
 
 
  SD(:,i)=y;
  
  

end



appleSD=[SD(:,1) SD(:,2)];

GoogleBR=-mean(SD(:,3:7)');
GoogleSP=-mean(SD(:,9:13)');


SDBR=mean([GoogleBR' SD(:,1')]')';
SDSP=mean([GoogleSP' SD(:,2')]')';

%figure
%plot(t,SDBR,'g',t,SDSP,'k')

SD=[SDBR SDSP];

end
