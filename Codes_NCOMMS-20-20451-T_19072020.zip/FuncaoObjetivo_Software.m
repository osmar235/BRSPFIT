function [ICU_E,Protection,ICUE1,ICUE2] = FuncaoObjetivo_Software(Xfo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Objective Function (we used in ESTECO�s mode Frontier (Esteco s.p.a; 2017R4-5.6.0.1) 


%INPUT
%CP: value for alpha after present day. RANGE USED:    max=0.28   min -0.5      
%ESTRATEGIA: Strategies tested; % 1 for stepping down 2 for intermittent or
%3 for Constant
%JANELA: # Number of day per window; Values: 1 2 ou 3 for 40 60 and 80 days 
%NOVOSD: 2 x the maximum SD values for stretagies 1 and 2 , 4 x the SD
%value for strategy 3.
%TEMPOCP %number of day from which protecion stays constant x 10. RANGE USED: min=300 %max=5000
%Region: 1 for Brazil 2 for S�o Paulo


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Output
%ICU_E: Number of people over ICU threshold 
%Protection: final protecion percentage value 
%ICUE1: Number of people over ICU threshold in the first peak of the pandemic
%ICUE2: Number of people over ICU threshold in the second peak of the pandemic 


CP=Xfo(1);
ESTRATEGIA=Xfo(2);
JANELA=Xfo(3);
NOVOSD=Xfo(4);
TEMPOCP=Xfo(5);
Region=Xfo(6);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Inputs
i=Region; 
DIA=24; %to set present day
%THRESHOLD: number of ICU threshhold value for Brazil is 30941 and for SP 8385 
if Region==1
    THRESHOLD=30941;
else
    THRESHOLD=8385;
end

%Regions names , population, cases factor and deats factor
Tablename1 = 'PAIS_POP_FATOR1_2_28052020.xls';
T1 = readtable(Tablename1);
paises=T1{:,1} ;
populacao=T1{:,2} ;
populacao=populacao.*1e6;
FATORCASOS=T1{:,3} ;
FATORMORTES=T1{:,4} ;

%Acc Cases, Acc deaths, and Recoveries 
Tablename2='dados_estados_completo_28052020.xls';
T2 = readtable(Tablename2);
fileData=T2{:,2:7};

%Optimized alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0 
Tablename3 ='optimized_results_28052020.xls';
T3 = readtable(Tablename3);
fileDataGU=T3{:,2:21};

%Function to estimate social distance from Google and Apple's data
SDT = Funcao_GOOGLE_APPLE_28052020;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


caso(i,:)=  fileDataGU(i,:);
SD=SDT(:,i)./100;
minNum= 50;  

DADOSMUNDO=fileData(:,(i*3-2:i*3));
Npop=populacao(i); 

CASOSREAL = FATORCASOS(i) * DADOSMUNDO(:,1);
DEATHSREAL = FATORMORTES(i)*DADOSMUNDO(:,2);
RECUPERADOSREAL=DADOSMUNDO(:,3);

N = length(CASOSREAL);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%setting model time resolution and starting and end data for model run
dt=.1;
t=0:dt:(730);
startDate = datenum('12-27-2019');
endDate = datenum('12-26-2021');
xData = linspace(startDate,endDate,7300);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Resampling of DATA

x = (1:N)'; 
y = CASOSREAL; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%CASOSREAL=p1(11:length(p1));
CASOSREAL=p1(1:length(p1));
y = DEATHSREAL; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%DEATHSREAL=p1(11:length(p1));
DEATHSREAL=p1(1:length(p1));
y = RECUPERADOSREAL; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%RECUPERADOSREAL=p1(11:length(p1));
RECUPERADOSREAL=p1(1:length(p1));

y = SD; 
xq1 = 0:.1:(N-.1);
p1 = pchip(x,y,xq1);
%RECUPERADOSREAL=p1(11:length(p1));
SD=p1(1:length(p1));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Starting analyses after 50 cases

N2 = length(CASOSREAL);
minNum=50;
CASOSREAL_orig=CASOSREAL;
t(CASOSREAL<=minNum)=[];
DEATHSREAL(CASOSREAL<=minNum)=[];
RECUPERADOSREAL(CASOSREAL<=minNum)=[];
SD(CASOSREAL<=minNum)=[];
xData(CASOSREAL<=minNum)=[];
CASOSREAL(CASOSREAL<=minNum)=[];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD set to zero for duration of time after present day not relevant for
%optmization
for cont=length(SD)+1:length(t)
    SD(cont)=0;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Retrieve optmized results

alpha= caso(i,1); 
beta=caso(i,2);  
Invtl=caso(i,3);  
Invti=caso(i,4); 
Invth=caso(i,5); 
Invtc=caso(i,6); 
ma=caso(i,7);
la=caso(i,8);
rla=caso(i,9);
midpla=caso(i,10);
dur=caso(i,11);
ca=caso(i,12);
fa=caso(i,13);
Npop=caso(i,14);  
E0=caso(i,15); 
I0=caso(i,16) ; 
H0=caso(i,17) ; 
C0=caso(i,18); % 
R0=caso(i,19); % 
D0=caso(i,20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%VARIACOES
SDQ=SD(length(CASOSREAL));
%SDQ=.80;

[S,U,E,I,H,C,D,R] = SUEIHCDR_OS_28052020_CASES(ESTRATEGIA,JANELA,NOVOSD,DIA,CP,TEMPOCP,SDQ,CASOSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD);

porctmascara=(U/Npop)*100;

%1 40 dias
%2 60 dias
%3 80 dias
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


startDate = fix(xData(1));
xData = linspace(startDate,endDate,length(C));



dataI=xData;
y=THRESHOLD;
%y=30941


%VARIAVEL ICU OVER THRESHOLD

%Int1=trapz(dataI,C)

curva=C-y;
for ith=1:length(curva)
    if curva(ith)<0
        curva(ith)=0;
    else
        curva(ith)=curva(ith);
    end
end


Intcurva=cumsum(curva).*dt*Invtc;
[pks,locs] = findpeaks(C);
primeiropico=locs(1);
Intcurva2opico=cumsum(curva(primeiropico+600:(length(C)))).*dt*Invtc;
Intcurva=Intcurva(length(C));
Intcurva2opico=Intcurva2opico(length(Intcurva2opico));
Protecao=porctmascara(length(porctmascara))   ;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%OUTPUTS
ICU_E = Intcurva;
Protection = Protecao;
ICUE2 = Intcurva2opico;
ICUE1 = ICU_E-ICUE2;

end
