
function Plot_modeloptimization_19072020(xData,dt,NROD,CASOSREAL,DEATHSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD)


melhorcaso=[alpha,beta,Invtl,Invti,Invth,Invtc,ma,ca,fa,E0,I0,H0,C0,R0,D0];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Numero de iteracoes
erro=0.01; 
contador=0;
%Incluir BARRA
h = waitbar(0, 'Please wait...');


for i95=1:NROD

a = 1-erro;
b = 1+erro;

r1 = (b-a).*rand + a;
r1=(r1*melhorcaso(1));

r2 = (b-a).*rand + a;
r2=(r2*melhorcaso(2));

r3 = (b-a).*rand + a;
r3=(r3*melhorcaso(3));

r4 = (b-a).*rand + a;
r4=(r4*melhorcaso(4));

r5 = (b-a).*rand + a;
r5=(r5*melhorcaso(5));

r6 = (b-a).*rand + a;
r6=(r6*melhorcaso(6));

r7 = (b-a).*rand + a;
r7=(r7*melhorcaso(7));

r8 = (b-a).*rand + a;
r8=(r8*melhorcaso(8));

r9 = (b-a).*rand + a;
r9=(r9*melhorcaso(9));

r10 = (b-a).*rand + a;
r10=(r10*melhorcaso(10));

r11 = (b-a).*rand + a;
r11=(r11*melhorcaso(11));

r12 = (b-a).*rand + a;
r12=(r12*melhorcaso(12));

r13 = (b-a).*rand + a;
r13=(r13*melhorcaso(13));

r14=melhorcaso(14);

r15 = (b-a).*rand + a;
r15=(r15*melhorcaso(15));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    alpha=r1;
    beta=r2;
    Invtl=r3;
    Invti=r4;
    Invth=r5;
    Invtc=r6;
    ma=r7;
    ca=r8 	 ;
    fa=r9 	 ;
    E0=r10 	 ;
    I0=r11 	 ;
    H0=r12 	 ;
    C0=r13 	 ;
    R0=r14 	 ;
    D0=r15  ;
   
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
la=0;
rla=0.1;
midpla=0.1;
dur=5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MODELO

[S,U,E,I,H,C,D,R] = SUEIHCDR_OS_19072020(CASOSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD);

    Ef(:,i95)=E;
    If(:,i95)=I;
    Hf(:,i95)=H;
    Cf(:,i95)=C;
    Df(:,i95)=D;
    Uf(:,i95)=U;
    Rf(:,i95)=R;
    Sf(:,i95)=S;
     
   zeta(i95)=r1;
    
    contador=contador+1;
 

waitbar(i95/NROD, h, ['Number of the test: ' num2str(i95)])

end

% close the waitbar
close(h)


S=mean(Sf');
E=mean(Ef');
I=mean(If');
H=mean(Hf');
C=mean(Cf');
R=mean(Rf');
D=mean(Df');
U=mean(Uf');



%IAf=Ef+If+Hf+Cf+Rf+Df;
IAf=cumsum(If)*dt*Invti;
IA=mean(IAf');
DRf=Df./IAf*100;
DR=mean(DRf');
Attack_Rate_f=(Rf+Df)/Npop*100;
Attack_Rate=mean(Attack_Rate_f');
Protected_f=(Uf)/Npop;
Protected=mean(Protected_f');

Rt_f=((((1-SD).*beta)./Invti))'.*(1-(Uf./Npop));
Rt=mean(Rt_f');
%EIHCf=Ef+If+Hf+Cf;
%EIHC=mean(EIHCf');


D_PDf=diff(Df)/dt;
D_PD=diff(D)/dt;




startDate = fix(xData(1));
endDate=startDate+length(S)/10;
xData = linspace(startDate,endDate,length(S));



dataI=xData;


Dstd=std(IAf')  ;  
ID=1.96.*Dstd;
Dstd=std(Df')  ;  
ID2=1.96.*Dstd;

dataIz=dataI(1:length(CASOSREAL));

figure
subplot(2,2,1) 
hold on
plot_areaerrorbar_Os(dataI,IA,ID)
title('Accumulated Data','FontSize',12)
   ylabel('Acc Cases','FontSize',12,'FontWeight','normal')%,'Color','r')
   % ylabel('Deaths','FontSize',12,'FontWeight','normal')%,'Color','r')
    xlabel('Date (m-d)','FontSize',12,'FontWeight','normal')%,'Color','r')
    tick5 = 737850:15:737938;
    set(gca, 'xtick', tick5);
    datetick('x', 'mm-dd','keepticks')
    %y1 = downsample (dataI1,10) ;
    %y2 = downsample (DEATHSREAL,10) ;
    %plot(y1,y2,'o','color','b')
    
    y1 = downsample (dataIz,10) ;
    y2 = downsample (CASOSREAL,10) ;
   %y2 = downsample (DEATHSREAL,10) ;
    
   % plot(y1,y2,'o','color','g')
    plot(y1,y2,'o','color','b')
    

plot_areaerrorbar_Os_yright(dataI,D,ID2)
ylabel('Acc Deaths','FontSize',12,'FontWeight','normal')%,'Color','r')
    y2 = downsample (DEATHSREAL,10) ;
     plot(y1,y2,'o','color','r')
  yyaxis right
  
  %  lgd=legend('95%-1% CIP','Model Results Acc_C','95%-1% CI-P','Model Results Acc_D','Corrected DC Data','Corrected DD Data');
%set(lgd,'FontSize',14);
    
    
subplot(2,2,2) 
hold on
%Residuos
IAr=IA(1:length(DEATHSREAL));
ResiduosC=CASOSREAL-IAr;
Dr=D(1:length(DEATHSREAL));
ResiduosD=DEATHSREAL-Dr;

plot(dataIz,ResiduosC,'b','LineWidth', 3)
title('Fitting Results','FontSize',16)
ylabel('Residuals Acc Cases','FontSize',16,'FontWeight','normal')%,'Color','r')
%tick5 = 737850:35:738055;
%set(gca, 'xtick', tick5);
%datetick('x', 'mm-dd','keepticks')
yyaxis right
plot(dataIz,ResiduosD,'r','LineWidth', 3)
yyaxis right
ylabel('Residuals Acc Deaths','FontSize',16,'FontWeight','normal')%,'Color','r')
tick5 = 737850:15:737938;
set(gca, 'xtick', tick5);
datetick('x', 'mm-dd','keepticks')

%lgd=legend('Residuals Cases','Residuals Deaths');
%set(lgd,'FontSize',14);   
    
   hold off





DEATHSREAL_PD=diff(DEATHSREAL)/dt;
DEATHSREAL_PD=movmean(DEATHSREAL_PD,70);
dataI1=xData(1:(length(CASOSREAL)));
z3=length(dataI1);
dataI3=dataI(2:z3);

z2=length(dataI);
dataI2=dataI(2:z2);
D_PD=movmean(D_PD,70);

CASOSREAL_PD=diff(CASOSREAL)/dt;
CASOSREAL_PD=movmean(CASOSREAL_PD,70);
IAf_PD=diff(IAf)/dt;
IA_PD=diff(IA)/dt;

P_I_f_PD=IAf_PD/Npop*100;
P_I_PD=mean(P_I_f_PD');

Rf_PD=diff(Rf)/dt;
Rf_PD=Rf_PD/Npop*100;
R_PD=diff(R)/dt;
R_PD=R_PD/Npop*100;

Protected_PD=diff(Protected)/dt;
Protected_f_PD=diff(Protected)/dt;
Dstd=std(Protected_f_PD')  ;  
IDP=1.96.*Dstd;

Rf_PD=Rf_PD/Npop*100;
R_PD=diff(R)/dt;
R_PD=R_PD/Npop*100;

Dstd=std(IAf_PD')  ;  
ID=1.96.*Dstd;

Dstd=std(D_PDf')  ;  
ID2=1.96.*Dstd;


subplot(2,2,3) 
hold on
plot_areaerrorbar_Os(dataI2,IA_PD,ID)
title('Daily Data','FontSize',12)
   ylabel('Daily New Cases','FontSize',16,'FontWeight','normal')%,'Color','r')
   % ylabel('Deaths','FontSize',12,'FontWeight','normal')%,'Color','r')
    xlabel('Date (m-d)','FontSize',16,'FontWeight','normal')%,'Color','r')
    tick5 = 737850:15:737953;
    set(gca, 'xtick', tick5);
    datetick('x', 'mm-dd','keepticks')
    %y1 = downsample (dataI1,10) ;
    %y2 = downsample (DEATHSREAL,10) ;
    %plot(y1,y2,'o','color','b')
    
    y1 = downsample (dataI3,10) ;
    y2 = downsample (CASOSREAL_PD,10) ;
   %y2 = downsample (DEATHSREAL,10) ;
    
   % plot(y1,y2,'o','color','g')
    plot(y1,y2,'o','color','b')
    

plot_areaerrorbar_Os_yright(dataI2,D_PD,ID2)
ylabel('Daily Deaths','FontSize',12,'FontWeight','normal')%,'Color','r')
    y2 = downsample (DEATHSREAL_PD,10) ;
   
    plot(y1,y2,'o','color','r')
  yyaxis right
  
    lgd=legend('95%-1% CI-P','Model Cases','95%-1% CI-P','Model Deaths','Data Cases','Data Deaths');
set(lgd,'FontSize',14);
    
    
    
    
    
   hold off
   
   


subplot(2,2,4) 
hold on
%Residuos
IA_PDr=IA_PD(1:length(DEATHSREAL_PD));
ResiduosC=CASOSREAL_PD-IA_PDr;
D_PDr=D_PD(1:length(DEATHSREAL_PD));
ResiduosD=DEATHSREAL_PD-D_PDr;

plot(dataI3,ResiduosC,'b','LineWidth', 3)
%title('Residuals','FontSize',16)
ylabel('Residuals Daily Cases','FontSize',16,'FontWeight','normal')%,'Color','r')
xlabel('Date (m-d)','FontSize',16,'FontWeight','normal')%,'Color','r')
%tick5 = 737850:35:738055;
%set(gca, 'xtick', tick5);
%datetick('x', 'mm-dd','keepticks')
yyaxis right
plot(dataI3,ResiduosD,'r','LineWidth', 3)
yyaxis right
ylabel('Residuals Daily Deaths','FontSize',16,'FontWeight','normal')%,'Color','r')
tick5 = 737850:15:737938;
set(gca, 'xtick', tick5);
datetick('x', 'mm-dd','keepticks')

lgd=legend('Residuals Daily Cases','Residuals Daily Deaths');
set(lgd,'FontSize',14);


end
