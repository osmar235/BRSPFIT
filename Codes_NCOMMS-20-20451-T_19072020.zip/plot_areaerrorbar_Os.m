
function plot_areaerrorbar_Os(t,data,error)
    % Default options
        color_area = [128 193 219]./255;    % Blue theme
        color_line = 'k'; %[ 52 148 186]./255;
        %color_area = [243 169 114]./255;    % Orange theme
        %color_line = [236 112  22]./255;
        alpha      = .5;
        line_width = 3;
   
        
    
    % Plotting the result
    %figure;
    t2= [t, fliplr(t)];
    patch = fill(t2, [data+error,fliplr(data-error)], color_area);
    set(patch, 'edgecolor', 'none');
    set(patch, 'FaceAlpha', alpha);
    hold on;
    plot(t, data, 'color', color_line, ...
        'LineWidth', line_width);
    %hold off;
    
end