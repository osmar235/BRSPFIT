function [S,U,E,I,H,C,D,R] = SUEIHCDR_OS_28052020_CASES(ESTRATEGIA,JANELA,NOVOSD,DIA,CP,TEMPOCP,SDQ,CASOSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD)

%Model Function Used in Objective Function used in ESTECO�s mode Frontier (Esteco s.p.a; 2017R4-5.6.0.1) 



SD_OR=SD;
beta0=beta;
q1A=length(CASOSREAL)+1;
q2A=length(CASOSREAL)+DIA;

%PROTECTION
alpha0=alpha;
alphaORI=alpha.*(log10(t+1))/max((log10(t+1)));
%alphaORI2=-.5*alpha.*(log10(t+1))/max((log10(t+1))); Figura 3 cenarios SD
alphaORI2=-CP*alpha.*(log10(t+1))/max((log10(t+1))); %Figura 2 cenarios SD
alphaORI3=-CP*alpha.*(log10(t+1))/max((log10(t+1)));
alphaORI4=-CP*alpha.*(log10(t+1))/max((log10(t+1)));

for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
alpha(isd)=alphaORI(isd);
end

%QUARENTENA
for isd=q1A:q2A %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
alpha(isd)=0;
end

%POSQUARENTENA 0-15 DIAS
for isd=q2A+1:q2A+1+TEMPOCP %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
alpha(isd)=alphaORI2(isd); %FIGURA01:0
end

for isd=q2A+1+TEMPOCP+1:length(t) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
alpha(isd)=0;%alphaORI4(isd);
end

dtf=.1;
%dur=40;
lac=t;

midpla=midpla;

for il=1:fix((2*midpla+dur)/dtf)
    lac(il)=la*(1./(1+exp(-rla*(t(il)-midpla))));
end


lacP=(.95).^(t-(2*midpla+dur))*la;


for il=fix((2*midpla+dur)/dtf):length(t)
    lac(il)=lacP(il);
end


la=lac;


if ESTRATEGIA==1 
    
    if JANELA==1



PT=390;
U0=0;


%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD_OR=SD;
SDf=SD(length(CASOSREAL));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=q17+PT;
q19=q18+1;
q20=q19+PT;
q21=q20+1;
q22=q21+PT;
q23=q22+1;
q24=q23+PT;
q25=q24+1;
q26=q25+PT;
q27=q26+1;
q28=q27+PT;
q29=q28+1;
q30=q29+PT;
q31=q30+1;
q32=q31+PT;
q33=q32+1;
q34=length(t);



for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end
%NOVOSD=.5*SDQ;


%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16; %0 .25 .7
end

for isd=q11:q12 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q13:q14 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

for isd=q15:q16 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

for isd=q17:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16;% .25 .7
end


%POSQUARENTENA 0-30 DIAS
for isd=q19:q20 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q21:q22 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q23:q24 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q25:q26 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16; %0 .25 .7
end

for isd=q27:q28 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q29:q30 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

for isd=q31:q32 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

for isd=q33:q34 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16;% .25 .7
end


beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end


S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);
%clear beta
    end

if JANELA==2


%MODELO SEIR com Inlclusao de HOSPITAL e UTI
%ESTRATEGIA 01
PT=600;
U0=0;


%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%


modelFun = @(Y,A,F) A*Y + F;
dt=.1;


%SD
SD=SD_OR;

SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end


q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=q17+PT;
q19=q18+1;
q20=q19+PT;
q21=q20+1;
q22=length(t);



for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end


%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16; %0 .25 .7
end

for isd=q11:q12 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q13:q14 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

for isd=q15:q16 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

for isd=q17:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16;% .25 .7
end


%POSQUARENTENA 0-30 DIAS
for isd=q19:q20 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q21:q22 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end



beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end



S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);



end



if JANELA==3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PT=800;


U0=0;



%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%


modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

%%DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=length(t);

for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end

%NOVOSD=.5*SDQ;



%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16; %0 .25 .7
end

for isd=q11:q12 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2;  %0 .25 .7
end

for isd=q13:q14 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

for isd=q15:q16 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/8; %0 .25 .7
end

for isd=q17:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/16; %0 .25 .7
end



beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end


S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);


end
end

if ESTRATEGIA==2


if JANELA==1

PT=390;

U0=0;


%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

%%DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=q17+PT;
q19=q18+1;
q20=q19+PT;
q21=q20+1;
q22=q21+PT;
q23=q22+1;
q24=q23+PT;
q25=q24+1;
q26=q25+PT;
q27=q26+1;
q28=q27+PT;
q29=q28+1;
q30=q29+PT;
q31=q30+1;
q32=q31+PT;
q33=q32+1;
q34=length(t);



for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end

%NOVOSD=.5*SDQ;

%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q11:q12 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q13:q14 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q15:q16 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q17:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0;% .25 .7
end


%POSQUARENTENA 0-30 DIAS
for isd=q19:q20 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q21:q22 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q23:q24 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q25:q26 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q27:q28 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q29:q30 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q31:q32 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q33:q34 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0;% .25 .7
end



beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end


S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);

end
if JANELA==2

U0=0;
PT=600;


%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

%%DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=q17+PT;
q19=q18+1;
q20=q19+PT;
q21=q20+1;
q22=length(t);



for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end

%NOVOSD=.5*SDQ;

%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q11:q12 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q13:q14 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q15:q16 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q17:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0;% .25 .7
end


%POSQUARENTENA 0-30 DIAS
for isd=q19:q20 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q21:q22 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %.10 .35 .8
end




beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end

S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);


end
if JANELA==3


U0=0;
PT=800;



%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

%%DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=length(t);

for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end
%NOVOSD=.5*SDQ;

%999

%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q11:q12 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q13:q14 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0; %0 .25 .7
end

for isd=q15:q16 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/2; %0 .25 .7
end

for isd=q17:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=0;% .25 .7
end



beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end


S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);

end
end

if ESTRATEGIA==3
    if JANELA==1

U0=0;
PT=390;




%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

%%DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=q17+PT;
q19=q18+1;
q20=q19+PT;
q21=q20+1;
q22=q21+PT;
q23=q22+1;
q24=q23+PT;
q25=q24+1;
q26=q25+PT;
q27=q26+1;
q28=q27+PT;
q29=q28+1;
q30=q29+PT;
q31=q30+1;
q32=q31+PT;
q33=q32+1;
q34=length(t);

for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end
%NOVOSD=.5*SDQ;

%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4;%0 .25 .7
end

for isd=q11:q34 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end



beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end


S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);
    end
    if JANELA==2
U0=0;
PT=600;


%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end


q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=q17+PT;
q19=q18+1;
q20=q19+PT;
q21=q20+1;
q22=length(t);

for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end
%NOVOSD=.5*SDQ;

%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4;%0 .25 .7
end

for isd=q11:q22 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end



%beta=beta*M*(1-SD);
beta=beta0*(1-SD);



for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end

S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);

    end
    if JANELA==3


U0=0;
PT=800;



%% Initial conditions
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end
%%

%break
modelFun = @(Y,A,F) A*Y + F;
%dt = median(diff(t));
dt=.1;
% ODE resolution

 
%midpoint=max(t)/2;

%SD
SD=SD_OR;
SDf=SDQ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SD APPLE
%SD=SD.*(log10(t+1))/max((log10(t+1)));
%Quarentena
for isd=1:length(CASOSREAL) %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SD(isd);
end

%%DIA=DIA*10;
%POS1 QUARENTENA
%POS1 QUARENTENA
q1=length(CASOSREAL)+1;
q2=length(CASOSREAL)+DIA;
q3=q2+1;
q4=q3+PT;
q5=q4+1;
q6=q5+PT;
q7=q6+1;
q8=q7+PT;
q9=q8+1;
q10=q9+PT;
q11=q10+1;
q12=q11+PT;
q13=q12+1;
q14=q13+PT;
q15=q14+1;
q16=q15+PT;
q17=q16+1;
q18=length(t);

for isd=q1:q2 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=SDQ; %.25 %45 
end

%POSQUARENTENA 0-30 DIAS
for isd=q3:q4 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.15 .40 .9
end

%POSQUARENTENA 15-45 DIAS
for isd=q5:q6 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %.10 .35 .8
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q7:q8 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

%POSQUARENTENA 45-finaldeano DIAS
for isd=q9:q10 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4;%0 .25 .7
end

for isd=q11:q18 %Para USA D1=65 dia 29022020 /hoje dia 125 DIA Q= 15 maio = dia 141 
SD(isd)=NOVOSD/4; %0 .25 .7
end

%figure
%plot(CASOSREAL)
%figure
%plot(SD)
%az=(SD01-SD02);
%bz=(az/SD02*2-1);
%cz=9/10;

%for isd=601:901
%SD(isd)=az./(1+bz*cz*exp(-isd));
%SD(isd)=.10;
%end

beta=beta0*(1-SD);

%RESTAR ALPHA FUNCAO
%alphaT(t)=alpha*t

%midpointalpha=max(t)/8;
%alpha=(3/4)*alpha.*(cos(2*pi*(1/240).*(t-t(1))+(pi/2)))+alpha/4;
%alpha=alpha0.*(cos(2*pi*(1/180).*(t-t(1))+((3*pi/2.155))));
%figure
%plot(t,alpha)%,t,alpha2,'r')
%mean(alpha2)
%alpha=alpha.*(1./(1+exp(-.1.*(t-midpointalpha))));

for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    %F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;     
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end

S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);
    end
end



end