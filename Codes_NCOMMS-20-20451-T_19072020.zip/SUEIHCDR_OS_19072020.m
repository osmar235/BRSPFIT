function [S,U,E,I,H,C,D,R] = SUEIHCDR_OS_19072020(CASOSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD)

%SUEIHCDR Model
%Susceptible, Unsusceptible, Exposed, Infected, Hospitalized, Critical, Dead, and Recovered

% Input
%
%   alpha: protection rate
%   beta: infection rate
%   Invtl: Inverse of the average latent period
%   Invti: Inverse of the average infectious period
%   Invth: Inverse of the average hospital period
%   Invtc: Inverse of the average critical period
%   ma: Fraction of infectious that are asymptomatic or mild 
%   ca: Fraction of hospitalized cases that turn critical and goes to ICU
%   fa: Fraction of critical cases that end up in death
%   Npop: population of the region
%   E0: Initial number of exposed cases
%   I0: Initial number of infectious cases
%   H0: Initial number of cases in hospital
%   C0: Initial number of cases in ICU
%   R0: Initial number of recovered cases
%   D0: Initial number of dead cases
%   t: 	period of model analyses
%   SD: Social Distance data estimation based on dat obtained from Google and Apple 
%
% Output
%   S: model results for Susceptible Cases 
%   U: model results for Unsusceptible Cases
%   E: model results for Exposed Cases 
%   I: model results for Infected Cases
%   H: model results for Hospitalized Cases
%   C: model results for Critical or ICU Cases
%   D: model results for Deaths
%   R: model results for Recovered Cases
%
% Author: Osmar Pinto Neto, Last modified 28052020




%Initial Conditions
U0=0;
N = numel(t);
Y = zeros(8,N);
Y(1,1) = Npop-E0-I0-H0-C0-R0-D0-U0;
Y(2,1) = E0;
Y(3,1) = I0;
Y(4,1) = H0;
Y(5,1) = C0;
Y(6,1) = R0;
Y(7,1) = D0;
Y(8,1) = U0;


if round(sum(Y(:,1))-Npop)~=0
    error('the sum must be zero because the total population (including the deads) is assumed constant');
end

%Model Function
modelFun = @(Y,A,F) A*Y + F;

%time resolution
dt=.1;

%calculatin l parameter for deaths out os hospital; not used when ICU estimations is the main goal
lac=t;
for il=1:fix((2*midpla+dur)/dt)
    lac(il)=la*(1./(1+exp(-rla*(t(il)-midpla))));
end
lacP=(.95).^(t-(2*midpla+dur))*la;
for il=fix((2*midpla+dur)/dt):length(t)
    lac(il)=lacP(il);
end
la=lac;


%Calculating alpha and Beta
alpha0=alpha;
le=length(CASOSREAL);
alphaT=alpha0.*(log10(t+1))/max((log10(t+1)));

for tt=1:le
alpha(tt)=alphaT(tt);
end

for tt=le+1:length(t)
alpha(tt)=0;
end

beta=beta*(1-SD);


%Solving Differential Equations

for ii=1:N-1
    
    A = getA_OS_11(alpha(ii),Invtl,Invti,Invth,Invtc,ma,la(ii),fa,ca);
    SI = Y(1,ii)*Y(3,ii);
    F = zeros(8,1);
    F(1:2,1) = [-beta(ii)/Npop;beta(ii)/Npop].*SI;  
    Y(:,ii+1) = RK4_OS(modelFun,Y(:,ii),A,F,dt);
end


S = Y(1,1:N);
E = Y(2,1:N);
I = Y(3,1:N);
H = Y(4,1:N);
C = Y(5,1:N);
R = Y(6,1:N);
D = Y(7,1:N);
U = Y(8,1:N);

end