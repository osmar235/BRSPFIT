function [alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,E0,I0,H0,C0,R0,D0,contador,contglobal,RMSE] = otimizador_OS_19072020(Peso_RAND,Peso_Atual,dt,CASOSREAL,DEATHSREAL,RECUPERADOSREAL,iteracoes,globalSkip,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD)

%optimizing function
%INPUTS

%Peso_RAND: Weight of randomnees in each iteration
%Peso_Atual: Weight of current best solution in each iteration
%dt: data time resolution
%Npop: Regions' population
%CASOSREAL: accumulated cases real data in dt time resolution
%DEATHSREAL: accumulated death real data in dt time resolution
%RECUPERADOSREAL: accumulated recovered cases real data in dt time resolution
%iteracoes: number of iterations what will be run for optmization
%globalSkip: numer of iterations before resetting to initial guess
%Initial guesses for model parameters: alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,E0,I0,H0,C0,R0,D0 
%t: period of model analyses
%SD: Social Distance data estimation based on dat obtained from Google and Apple  

%OUTPUTS
%Optmized model parameters: alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,E0,I0,H0,C0,R0,D0 
%contador: number of iterations that resulted in improved solutions
%contglobal: number of times routine resetted to initital guess
%RMSE: minimum root mean square error considering two time series

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Weight for optimizing Daily Cases and Daily Deaths
%Daily deaths Real
CASOSREAL_PD=diff(CASOSREAL)/dt;
DEATHSREAL_PD=diff(DEATHSREAL)/dt;

CASOSREAL_PD=movmean(CASOSREAL_PD,70);
DEATHSREAL_PD=movmean(DEATHSREAL_PD,70);

F1=sqrt(mean(CASOSREAL_PD.^2));
F2=sqrt(mean(DEATHSREAL_PD.^2));
FRMSE=F1/F2;

PESORMSCASOS=(1/(FRMSE+1)); %Weight for Acc Cases
PESORMSDEATHS=(FRMSE/(FRMSE+1));%Weight for Acc Deaths


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initial Guess
melhorcaso=[alpha,beta,Invtl,Invti,Invth,Invtc,ma,0,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0];
caso1=melhorcaso;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Baseline Values 

[Si,Ui,Ei,Ii,Hi,Ci,Di,Ri] = SUEIHCDR_OS_19072020(CASOSREAL,alpha,beta,Invtl,Invti,Invth,Invtc,ma,la,rla,midpla,dur,ca,fa,Npop,E0,I0,H0,C0,R0,D0,t,SD);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Baseline variables
IAi=cumsum(Ii)*dt*Invti;
IAi=IAi(1:length(CASOSREAL));
IHCi=Ii+Hi+Ci;
IHCi=IHCi(1:length(CASOSREAL));
Di=Di(1:length(CASOSREAL));
Ri=Ri(1:length(CASOSREAL));
Ci=Ci(1:length(CASOSREAL));
Ii=Ii(1:length(CASOSREAL));

%Baseline RMSE


%Daily Deaths Model
IAi_PD=diff(IAi)/dt;
Di_PD=diff(Di)/dt;
       
RMSE_CASOS(1)=sqrt(mean((CASOSREAL_PD-(IAi_PD)).^2));
RMSE_DEATHS(1)=sqrt(mean((DEATHSREAL_PD-Di_PD).^2));
RMSE_TOTAL(1)=PESORMSCASOS*RMSE_CASOS(1)+PESORMSDEATHS*RMSE_DEATHS(1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%counters
contglobal=0;
contador=0;
rodadasEMPTY=0;

%Incluir BARRA
h = waitbar(0, 'Please wait...');

%First optimization loop varibles within reported ranges

for i=2:fix(iteracoes*.8)

%alpha    
a=0.01;
b=0.04;
r1 = (b-a).*rand + a;
r1=(Peso_RAND*r1+Peso_Atual*melhorcaso(1));

%beta
a=0.4;
b=0.8;
r2 = (b-a).*rand + a;
r2=(Peso_RAND*r2+Peso_Atual*melhorcaso(2));

%Invtl
a = .5;
b =  2; 
r3 = (b-a).*rand + a;
r3=(Peso_RAND*r3+Peso_Atual*melhorcaso(3));

%Invti
a = 1/15; 
b = 1/5;
r4 = (b-a).*rand + a;
r4=(Peso_RAND*r4+Peso_Atual*melhorcaso(4));

%Invth
a = 1/7; %
b = 1/3;
r5 = (b-a).*rand + a;
r5=(Peso_RAND*r5+Peso_Atual*melhorcaso(5));

%Invtc
a = 1/21; %
b = 1/7;
r6 = (b-a).*rand + a;
r6=(Peso_RAND*r6+Peso_Atual*melhorcaso(6));

%ma
a = 0.65; %0.0
b = 0.99;
r7 = (b-a).*rand + a;
r7=(Peso_RAND*r7+Peso_Atual*melhorcaso(7));

%la
r8=0;

%rla
a = melhorcaso(9)*.90;
b = melhorcaso(9)*1.1;
r9 = (b-a).*rand + a;
r9=(Peso_RAND*r9+Peso_Atual*melhorcaso(9));

%midpla
a = melhorcaso(10)*.80;
b = melhorcaso(10)*1.2;
r10 = (b-a).*rand + a;
r10=(Peso_RAND*r10+Peso_Atual*melhorcaso(10));

%dur
a = melhorcaso(11)*.80;
b = melhorcaso(11)*1.2;
r11 = (b-a).*rand + a;
r11=(Peso_RAND*r11+Peso_Atual*melhorcaso(11));

%c
a = 0.25;
b = 0.50;  
r12 = (b-a).*rand + a;
r12=(Peso_RAND*r12+Peso_Atual*melhorcaso(12));

%f
a = 0.45;
b = 0.55;  %0.08
r13 = (b-a).*rand + a;
r13=(Peso_RAND*r13+Peso_Atual*melhorcaso(13));

%Npop %it does not change
r14=melhorcaso(14);

%E0
a = fix(.5*E0);
b = 2*E0;
r15 = (b-a).*rand + a;
r15=fix(Peso_RAND*r15+Peso_Atual*melhorcaso(15));

%I0
a = fix(.5*I0);
b = 2*I0;
r16 = (b-a).*rand + a;
r16=fix(Peso_RAND*r16+Peso_Atual*melhorcaso(16));

%H0
a = fix(.5*H0);
b = 2*H0;
r17 = (b-a).*rand + a;
r17=fix(Peso_RAND*r17+Peso_Atual*melhorcaso(16));

%C0
a = fix(.5*C0);
b = 2*C0;
r18 = (b-a).*rand + a;
r18=fix(Peso_RAND*r18+Peso_Atual*melhorcaso(18));

%R0
a = fix(.5*R0);
b = 2*R0;
r19 = (b-a).*rand + a;
r19=fix(Peso_RAND*r19+Peso_Atual*melhorcaso(19));

%D0
a = fix(.5*D0);
b = 2*D0;
r20 = (b-a).*rand + a;
r20=fix(Peso_RAND*r20+Peso_Atual*melhorcaso(20));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Current case for optimization test
caso=[r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18,r19,r20];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%model run

[S,U,E,I,H,C,D,R] = SUEIHCDR_OS_19072020(CASOSREAL,caso(1),caso(2),caso(3),caso(4),caso(5),caso(6),caso(7), caso(8),caso(9),caso(10),caso(11),caso(12),caso(13),caso(14),caso(15),caso(16),caso(17),caso(18),caso(19),caso(20),t,SD);

IHC=I+H+C;
IA=cumsum(I)*dt*r4;
IA=IA(1:length(CASOSREAL));
IHC=IHC(1:length(CASOSREAL));
D=D(1:length(CASOSREAL));
R=R(1:length(CASOSREAL));
I=I(1:length(CASOSREAL));
C=C(1:length(CASOSREAL));
H=H(1:length(CASOSREAL));

%Daily Deaths Model
IA_PD=diff(IA)/dt;
D_PD=diff(D)/dt;

%SCORE verification
        
RMSE_CASOS(i)=sqrt(mean((CASOSREAL_PD-IA_PD).^2));
RMSE_DEATHS(i)=sqrt(mean((DEATHSREAL_PD-D_PD).^2));
RMSE_TOTAL(i)=PESORMSCASOS*RMSE_CASOS(i)+PESORMSDEATHS*RMSE_DEATHS(i);


%saving minimum set

[CRMSE,IRMSE] = min(RMSE_TOTAL);

 
if RMSE_TOTAL(i) <= CRMSE %&& distATUAL(i)<distMIN
    
    Sf=S;
    Ef=E;
    Ifinal=I;
    Hf=H;
    Cf=C;
    Rf=R;
    Df=D;
    IA_PDf=IA_PD;
    D_PDf=D_PD;
    Uf=U;
    melhorcaso=caso;
    melhorcasof=caso;
    contador=contador+1;
    rodadasEMPTY=0;
    essecaso=[r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18,r19,r20];

    
else
    rodadasEMPTY=rodadasEMPTY+1;
    
    
end

if rodadasEMPTY>globalSkip
    melhorcaso=caso1;
    rodadasEMPTY=0;
    contglobal=contglobal+1;
end
    
 %end
waitbar(i/iteracoes, h, ['Number of the test: ' num2str(i)])

end


%%%%
%Loop 2 for converging solution


for i=fix(iteracoes*.8)+1:iteracoes

a = melhorcaso(1)*.95;
b = melhorcaso(1)*1.05;      
r1 = (b-a).*rand + a;
r1=(Peso_RAND*r1+Peso_Atual*melhorcaso(1));

a = melhorcaso(2)*.95;
b = melhorcaso(2)*1.05;      
r2 = (b-a).*rand + a;
r2=(Peso_RAND*r2+Peso_Atual*melhorcaso(2));

a = melhorcaso(3)*.95;
b = melhorcaso(3)*1.05;
r3 = (b-a).*rand + a;
r3=(Peso_RAND*r3+Peso_Atual*melhorcaso(3));


a = melhorcaso(4)*.95;
b = melhorcaso(4)*1.05;
r4 = (b-a).*rand + a;
r4=(Peso_RAND*r4+Peso_Atual*melhorcaso(4));

a = melhorcaso(5)*.95;
b = melhorcaso(5)*1.05;
r5 = (b-a).*rand + a;
r5=(Peso_RAND*r5+Peso_Atual*melhorcaso(5));

a = melhorcaso(6)*.95;
b = melhorcaso(6)*1.05;
r6 = (b-a).*rand + a;
r6=(Peso_RAND*r6+Peso_Atual*melhorcaso(6));


a = melhorcaso(7)*.95;
b = melhorcaso(7)*1.05;
r7 = (b-a).*rand + a;
r7=(Peso_RAND*r7+Peso_Atual*melhorcaso(7));

r8=0;

a = melhorcaso(9)*.95;
b = melhorcaso(9)*1.05;
r9 = (b-a).*rand + a;
r9=(Peso_RAND*r9+Peso_Atual*melhorcaso(9));

a = melhorcaso(10)*.95;
b = melhorcaso(10)*1.05;
r10 = (b-a).*rand + a;
r10=(Peso_RAND*r10+Peso_Atual*melhorcaso(10));

a = melhorcaso(11)*.95;
b = melhorcaso(11)*1.05;
r11 = (b-a).*rand + a;
r11=(Peso_RAND*r11+Peso_Atual*melhorcaso(11));

a = melhorcaso(12)*.95;
b = melhorcaso(12)*1.05;
r12 = (b-a).*rand + a;
r12=(Peso_RAND*r12+Peso_Atual*melhorcaso(12));


a = melhorcaso(13)*.95;
b = melhorcaso(13)*1.05;  %0.08
r13 = (b-a).*rand + a;
r13=(Peso_RAND*r13+Peso_Atual*melhorcaso(13));

r14=melhorcaso(14);

a = melhorcaso(15)*.95;
b = melhorcaso(15)*1.05;
r15 = (b-a).*rand + a;
r15=fix(Peso_RAND*r15+Peso_Atual*melhorcaso(15));

a = melhorcaso(16)*.95;
b = melhorcaso(16)*1.05;
r16 = (b-a).*rand + a;
r16=fix(Peso_RAND*r16+Peso_Atual*melhorcaso(16));

a = melhorcaso(17)*.95;
b = melhorcaso(17)*1.05;
r17 = (b-a).*rand + a;
r17=fix(Peso_RAND*r17+Peso_Atual*melhorcaso(16));

a = melhorcaso(18)*.95;
b = melhorcaso(18)*1.05;
r18 = (b-a).*rand + a;
r18=fix(Peso_RAND*r18+Peso_Atual*melhorcaso(18));

a = melhorcaso(19)*.95;
b = melhorcaso(19)*1.05;
r19 = (b-a).*rand + a;
r19=fix(Peso_RAND*r19+Peso_Atual*melhorcaso(19));

a = melhorcaso(20)*.95;
b = melhorcaso(20)*1.05;
r20 = (b-a).*rand + a;
r20=fix(Peso_RAND*r20+Peso_Atual*melhorcaso(20));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%CRIAR
caso=[r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18,r19,r20];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[S,U,E,I,H,C,D,R] = SUEIHCDR_OS_19072020(CASOSREAL,caso(1),caso(2),caso(3),caso(4),caso(5),caso(6),caso(7), caso(8),caso(9),caso(10),caso(11),caso(12),caso(13),caso(14),caso(15),caso(16),caso(17),caso(18),caso(19),caso(20),t,SD);


%Limitar em minimo 50
IHC=I+H+C;
IA=cumsum(I)*dt*r4;
IA=IA(1:length(CASOSREAL));
IHC=IHC(1:length(CASOSREAL));
D=D(1:length(CASOSREAL));
R=R(1:length(CASOSREAL));
I=I(1:length(CASOSREAL));
C=C(1:length(CASOSREAL));
H=H(1:length(CASOSREAL));


%Daily Deaths Model
IA_PD=diff(IA)/dt;
D_PD=diff(D)/dt;

%SCORE verification
        
RMSE_CASOS(i)=sqrt(mean((CASOSREAL_PD-(IA_PD)).^2));
RMSE_DEATHS(i)=sqrt(mean((DEATHSREAL_PD-D_PD).^2));
RMSE_TOTAL(i)=PESORMSCASOS*RMSE_CASOS(i)+PESORMSDEATHS*RMSE_DEATHS(i);    
    

[CRMSE,IRMSE] = min(RMSE_TOTAL);

 
if RMSE_TOTAL(i) <= CRMSE %&& distATUAL(i)<distMIN
    
    Sf=S;
    Ef=E;
    Ifinal=I;
    Hf=H;
    Cf=C;
    Rf=R;
    Df=D;
    IA_PDf=IA_PD;
    D_PDf=D_PD;
    Uf=U;
    melhorcaso=caso;
    melhorcasof=caso;
    contador=contador+1;
    rodadasEMPTY=0;
    essecaso=[r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18,r19,r20];

    
else
    rodadasEMPTY=rodadasEMPTY+1;
    
    
end

if rodadasEMPTY>globalSkip
    melhorcaso=caso1;
    rodadasEMPTY=0;
    contglobal=contglobal+1;
end
    
 %end
waitbar(i/iteracoes, h, ['Number of the test: ' num2str(i)])

end

% close the waitbar
close(h)


%Plotting Results
if contador>0
%IHCf=Ifinal+Hf+Cf;
%IAf=cumsum(Ifinal)*dt*melhorcaso(4);
%IAf=IAf(1:length(CASOSREAL));
%IHCf=IHCf(1:length(CASOSREAL));
%Ifinal=Ifinal(1:length(CASOSREAL));
%Rf=Rf(1:length(CASOSREAL));
figure
tgraph=0:1:length(CASOSREAL_PD)-1;
plot(tgraph,IA_PDf,tgraph,CASOSREAL_PD,'o')
figure
tgraph=0:1:length(DEATHSREAL_PD)-1;
plot(tgraph,D_PDf,tgraph,DEATHSREAL_PD,'o')



else
disp('Caso original ja era otimizado')
%melhorcasof=caso1;
essecaso=caso1;
%Di_PD=Di_PD(1:length(CASOSREAL));
%Ri=Ri(1:length(CASOSREAL));
figure
tgraph=0:1:length(CASOSREAL_PD)-1;
plot(tgraph,IAi_PD,tgraph,CASOSREAL_PD,'o')
tgraph=0:1:length(DEATHSREAL_PD)-1;
figure
plot(tgraph,Di_PD,tgraph,DEATHSREAL_PD,'o')




end

%OUTPUT PARAMETERS

melhorcaso=essecaso;
alpha= melhorcaso(1); 
beta=melhorcaso(2);  
Invtl=melhorcaso(3);  
Invti=melhorcaso(4); 
Invth=melhorcaso(5); 
Invtc=melhorcaso(6); 
ma=melhorcaso(7);
la=melhorcaso(8);
rla=melhorcaso(9);
midpla=melhorcaso(10);
dur=melhorcaso(11);
ca=melhorcaso(12);
fa=melhorcaso(13);
E0=melhorcaso(15); 
I0=melhorcaso(16) ; 
H0=melhorcaso(17) ; 
C0=melhorcaso(18);  
R0=melhorcaso(19);  
D0=melhorcaso(20);
RMSE=CRMSE;

end
